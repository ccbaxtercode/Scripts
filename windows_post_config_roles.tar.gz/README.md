# Windows VM Post-Configuration - Roles

## 📦 İçerik

3 ayrı role ve post-configuration task dosyası:

```
roles/
├── ad_query/                          # AD Object Query Role
│   ├── defaults/main.yml
│   ├── tasks/main.yml
│   └── files/ad_query.py
├── windows_domain_join/               # Windows Domain Join Role
│   ├── defaults/main.yml
│   └── tasks/main.yml
├── windows_remote_execute/            # Windows Remote Execute (PSExec)
│   ├── defaults/main.yml
│   └── tasks/main.yml
└── vcenter_vm_create/
    └── tasks/post_configuration.yml   # Post-Config Ana Task
```

---

## 🎯 Windows Post-Configuration Flow

```
1. Domain Join (microsoft.ad.membership)
   └─> Reboot YOK
   
2. 10 saniye bekle
   └─> AD replication için
   
3. AD Query Role
   └─> VM'in AD'de olduğunu doğrula
   
4. Remote Desktop Users + Reboot (PSExec)
   └─> Add-LocalGroupMember
   └─> shutdown -r -f -t 10
   
5. ✓ Tamamlandı
```

---

## 🔧 Role Detayları

### 1️⃣ **ad_query** Role

**Amaç:** Active Directory'de object sorgulama

**Özellikler:**
- ✅ DNS SRV discovery (otomatik DC bulma)
- ✅ Multi-DC support (failover)
- ✅ Retry logic (3x, 5s delay)
- ✅ LDAPS + certificate validation
- ✅ User, Computer, Group query

**Kullanım:**
```yaml
- name: "AD'de VM Kontrolü"
  ansible.builtin.include_role:
    name: ad_query
  vars:
    ad_query_object_type: "computer"
    ad_query_domain: "domain1.local"
    ad_query_object_name: "VDI-MEHMET01"
    ad_query_username: "admin@domain1.local"
    ad_query_password: "P@ssw0rd"
```

**Sonuç:**
```yaml
ad_query_result:
  found: true
  name: "VDI-MEHMET01"
  dn: "CN=VDI-MEHMET01,OU=Workstations,DC=domain1,DC=local"
  server: "dc1.domain1.local"
```

---

### 2️⃣ **windows_domain_join** Role

**Amaç:** Windows VM'i domain'e ekleme

**Özellikler:**
- ✅ microsoft.ad.membership modülü
- ✅ OU path desteği
- ✅ Reboot kontrolü (optional)

**Kullanım:**
```yaml
- name: "Domain Join"
  ansible.builtin.include_role:
    name: windows_domain_join
  vars:
    windows_dj_target_host: "new_vm_temp"
    windows_dj_domain: "domain1.local"
    windows_dj_domain_admin: "admin@domain1.local"
    windows_dj_domain_password: "P@ssw0rd"
    windows_dj_ou_path: "OU=Workstations,OU=Production,DC=domain1,DC=local"
    windows_dj_reboot: false  # Reboot yok
```

---

### 3️⃣ **windows_remote_execute** Role

**Amaç:** Windows VM'de PowerShell script çalıştırma

**Özellikler:**
- ✅ community.windows.psexec modülü
- ✅ Elevated (admin) execution
- ✅ PowerShell stdin support

**Kullanım:**
```yaml
- name: "RDU Group + Reboot"
  ansible.builtin.include_role:
    name: windows_remote_execute
  vars:
    windows_target_host: "192.168.1.100"
    windows_target_user: "Administrator"
    windows_target_password: "P@ss"
    windows_powershell_script: |
      Add-LocalGroupMember -Group 'Remote Desktop Users' -Member 'DOMAIN\mehmet'
      shutdown -r -f -t 10
```

---

## 📋 Tam Kullanım Örneği

`post_config_usage_example.yml` dosyasına bakın.

**Özet:**
```yaml
tasks:
  # 1. Domain Join
  - include_role: windows_domain_join
  
  # 2. Bekle
  - pause: seconds=10
  
  # 3. AD Doğrula
  - include_role: ad_query
  
  # 4. RDU + Reboot
  - include_role: windows_remote_execute
```

---

## 🔐 Gereksinimler

### Python Modülleri (Execution Environment)
```bash
pip install ldap3 dnspython --break-system-packages
```

### Ansible Collections
```bash
ansible-galaxy collection install microsoft.ad
ansible-galaxy collection install community.windows
```

### Windows VM Gereksinimleri
- ✅ WinRM aktif (port 5985)
- ✅ Template'te local admin user
- ✅ PSExec erişimi (port 445)

---

## 🚀 AWX Entegrasyonu

1. **Roles'leri AWX Project'e ekle**
   ```
   your_project/
   └── roles/
       ├── ad_query/
       ├── windows_domain_join/
       └── windows_remote_execute/
   ```

2. **Credentials ekle**
   - Domain Admin (Custom Credential Type)
   - Template Admin (Machine Credential)

3. **Job Template oluştur**
   - Inventory: Dynamic (VM creation sonrası)
   - Playbook: main.yml

---

## 🐛 Troubleshooting

### AD Query "Not Found"
```
[ERROR] Object not found on any DC
```
**Sebep:** AD replication gecikmesi  
**Çözüm:** Bekleme süresini artır (10s → 30s)

### PSExec Bağlantı Hatası
```
[ERROR] Failed to connect
```
**Sebep:** Port 445 kapalı veya firewall  
**Çözüm:** Windows Firewall ayarlarını kontrol et

### Domain Join Credential Hatası
```
[ERROR] Logon session does not exist
```
**Sebep:** CredSSP gerekli (kullanmıyoruz)  
**Çözüm:** microsoft.ad.membership + WinRM NTLM kullanıyoruz (çözüldü)

---

## 📄 Lisans

Internal use only.

## 👤 Geliştirici

Kadir - VMware vCenter Automation
