#!/usr/bin/env python3
# Dosya: roles/ad_query/files/ad_query.py
# Açıklama: Active Directory Query Tool (Multi-DC Support + DNS SRV Discovery)

"""
AD Query Tool - Multi-DC Support
- DNS SRV discovery ile otomatik DC bulma
- Multi-DC failover + retry logic
- User, Computer, Group object query
- LDAPS with certificate validation + fallback
"""

import ssl
import json
import sys
import os
import time

try:
    from ldap3 import Server, Connection, Tls, SUBTREE, ALL
    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False
    print("[ERROR] ldap3 not available")
    sys.exit(1)

try:
    import dns.resolver
    DNS_AVAILABLE = True
except ImportError:
    DNS_AVAILABLE = False

# Parameters
OBJECT_TYPE = sys.argv[1] if len(sys.argv) > 1 else None
AD_DOMAIN = sys.argv[2] if len(sys.argv) > 2 else None
OBJECT_NAME = sys.argv[3] if len(sys.argv) > 3 else None

# Credentials from environment
AD_USER = os.getenv("AD_USER")
AD_PASSWORD = os.getenv("AD_PASSWORD")
AD_CERT_PATH = os.getenv("AD_CERT_PATH", "")
AD_RETRY_COUNT = int(os.getenv("AD_RETRY_COUNT", "3"))
AD_RETRY_DELAY = int(os.getenv("AD_RETRY_DELAY", "5"))

# Validate inputs
if not all([OBJECT_TYPE, AD_DOMAIN, OBJECT_NAME]):
    print(json.dumps({"found": False, "error": "Missing parameters"}))
    sys.exit(1)

if OBJECT_TYPE not in ["user", "computer", "group"]:
    print(json.dumps({"found": False, "error": f"Invalid object_type: {OBJECT_TYPE}"}))
    sys.exit(1)

if not AD_USER or not AD_PASSWORD:
    print(json.dumps({"found": False, "error": "Missing AD credentials"}))
    sys.exit(1)

# ============================================
# DNS SRV DISCOVERY
# ============================================

def discover_domain_controllers(domain):
    """DNS SRV query ile tüm DC'leri bul
    
    Returns:
        list: DC hostname listesi (priority/weight sıralı)
    """
    if not DNS_AVAILABLE:
        print(f"[WARN] dnspython not available, using domain as DC: {domain}")
        return [domain]
    
    srv_record = f"_ldap._tcp.dc._msdcs.{domain}"
    
    try:
        print(f"[INFO] DNS SRV query: {srv_record}")
        answers = dns.resolver.resolve(srv_record, 'SRV')
        
        # Priority/weight sıralaması
        dc_list = sorted(answers, key=lambda x: (x.priority, -x.weight))
        dc_hostnames = [str(dc.target).rstrip('.') for dc in dc_list]
        
        print(f"[INFO] Found {len(dc_hostnames)} DCs: {', '.join(dc_hostnames)}")
        return dc_hostnames
        
    except Exception as e:
        print(f"[WARN] DNS SRV discovery failed: {e}, using domain as DC")
        return [domain]

# ============================================
# TLS CONFIGURATION
# ============================================

def get_tls_config():
    """TLS configuration with certificate fallback"""
    tls_config = Tls()
    
    if AD_CERT_PATH and os.path.exists(AD_CERT_PATH):
        print(f"[INFO] Using certificate: {AD_CERT_PATH}")
        tls_config = Tls(
            ca_certs_file=AD_CERT_PATH,
            validate=ssl.CERT_REQUIRED
        )
    else:
        print("[WARN] No certificate, using insecure connection")
        tls_config = Tls(validate=ssl.CERT_NONE)
    
    return tls_config

# ============================================
# AD CONNECTION TEST
# ============================================

def test_credentials(dc_hostname):
    """Test AD credentials on first available DC"""
    try:
        print(f"[INFO] Testing credentials on: {dc_hostname}")
        
        tls_config = get_tls_config()
        server = Server(dc_hostname, port=636, use_ssl=True, get_info=ALL, tls=tls_config)
        conn = Connection(server, user=AD_USER, password=AD_PASSWORD, auto_bind=True)
        
        if not conn.bind():
            return False, f"Authentication failed: {conn.result}"
        
        conn.unbind()
        print(f"[INFO] ✓ Credentials valid")
        return True, "OK"
        
    except Exception as e:
        return False, str(e)

# ============================================
# AD QUERY
# ============================================

def search_ad_object(dc_hostname, base_dn, search_filter, attributes):
    """Search AD object on specific DC with retry logic"""
    
    for attempt in range(1, AD_RETRY_COUNT + 1):
        try:
            print(f"[INFO] Query DC: {dc_hostname} (Attempt {attempt}/{AD_RETRY_COUNT})")
            
            tls_config = get_tls_config()
            server = Server(dc_hostname, port=636, use_ssl=True, get_info=ALL, tls=tls_config)
            conn = Connection(server, user=AD_USER, password=AD_PASSWORD, auto_bind=True)
            
            if not conn.bind():
                print(f"[WARN] Bind failed: {conn.result}")
                if attempt < AD_RETRY_COUNT:
                    time.sleep(AD_RETRY_DELAY)
                continue
            
            # Search
            conn.search(
                search_base=base_dn,
                search_filter=search_filter,
                search_scope=SUBTREE,
                attributes=attributes
            )
            
            if conn.entries:
                entry = conn.entries[0]
                result = {
                    "found": True,
                    "name": str(entry.cn) if hasattr(entry, 'cn') else OBJECT_NAME,
                    "dn": str(entry.entry_dn),
                    "server": dc_hostname,
                    "attributes": {}
                }
                
                # Attributes
                for attr in attributes:
                    if hasattr(entry, attr):
                        value = getattr(entry, attr).value
                        result["attributes"][attr] = str(value) if value else ""
                
                conn.unbind()
                return result
            
            conn.unbind()
            
            # Not found, retry
            if attempt < AD_RETRY_COUNT:
                print(f"[INFO] Object not found, retrying in {AD_RETRY_DELAY}s...")
                time.sleep(AD_RETRY_DELAY)
            
        except Exception as e:
            print(f"[ERROR] DC query error: {str(e)}")
            if attempt < AD_RETRY_COUNT:
                time.sleep(AD_RETRY_DELAY)
    
    return None

# ============================================
# MAIN SEARCH
# ============================================

def main():
    """Main search logic"""
    
    print("=" * 60)
    print(f"AD QUERY: {OBJECT_TYPE.upper()} - {OBJECT_NAME}")
    print(f"Domain: {AD_DOMAIN}")
    print("=" * 60)
    
    # Discover DCs
    dc_list = discover_domain_controllers(AD_DOMAIN)
    
    if not dc_list:
        print(json.dumps({"found": False, "error": "No domain controllers found"}))
        sys.exit(1)
    
    # Test credentials on first DC
    success, message = test_credentials(dc_list[0])
    if not success:
        print(json.dumps({"found": False, "error": f"Credential test failed: {message}"}))
        sys.exit(1)
    
    # Build search filter
    base_dn = ",".join([f"DC={part}" for part in AD_DOMAIN.split(".")])
    
    if OBJECT_TYPE == "user":
        search_filter = f"(&(objectClass=user)(sAMAccountName={OBJECT_NAME}))"
        attributes = ["cn", "sAMAccountName", "distinguishedName", "mail"]
    elif OBJECT_TYPE == "computer":
        search_filter = f"(&(objectClass=computer)(cn={OBJECT_NAME}))"
        attributes = ["cn", "sAMAccountName", "distinguishedName", "operatingSystem"]
    elif OBJECT_TYPE == "group":
        search_filter = f"(&(objectClass=group)(cn={OBJECT_NAME}))"
        attributes = ["cn", "sAMAccountName", "distinguishedName", "member"]
    
    print(f"[INFO] Search filter: {search_filter}")
    print(f"[INFO] Base DN: {base_dn}")
    print("=" * 60)
    
    # Query all DCs until found
    for dc in dc_list:
        result = search_ad_object(dc, base_dn, search_filter, attributes)
        
        if result:
            print("=" * 60)
            print(f"[SUCCESS] ✓ Object found on: {dc}")
            print("=" * 60)
            print(json.dumps(result))
            sys.exit(0)
    
    # Not found on any DC
    print("=" * 60)
    print(f"[ERROR] Object not found on any DC")
    print("=" * 60)
    print(json.dumps({
        "found": False,
        "error": f"{OBJECT_TYPE} '{OBJECT_NAME}' not found after checking {len(dc_list)} DCs"
    }))
    sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("[INFO] Interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Unexpected error: {str(e)}")
        print(json.dumps({"found": False, "error": f"Script error: {str(e)}"}))
        sys.exit(1)
